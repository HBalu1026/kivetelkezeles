﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnOsszead_Click(object sender, RoutedEventArgs e)
        {
            double aSzam, bSzam;
            ellenorzes(out aSzam, out bSzam);
            lblEredmeny.Content = aSzam + bSzam;
        }

        private void ellenorzes(out double aSzam, out double bSzam)
        {
            aSzam = 0;
            try
            {
                aSzam = Convert.ToDouble(txtEgyikSzam.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("nem jou");
                txtEgyikSzam.Text = "";
                txtEgyikSzam.Focus();
            }
            bSzam = 0;
            try
            {
                bSzam = Convert.ToDouble(txtMasikSzam.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("nem jou");
                txtMasikSzam.Text = "";
                txtMasikSzam.Focus();
            }
        }

        private void btnKivon_Click(object sender, RoutedEventArgs e)
        {
            double aSzam, bSzam;
            ellenorzes(out aSzam, out bSzam);
            lblEredmeny.Content = aSzam - bSzam;
        }

        private void btnSzoroz_Click(object sender, RoutedEventArgs e)
        {
            double aSzam, bSzam;
            ellenorzes(out aSzam, out bSzam);
            lblEredmeny.Content = aSzam * bSzam;
        }

        private void btnOszt_Click(object sender, RoutedEventArgs e)
        {
            double aSzam, bSzam;
            ellenorzes(out aSzam, out bSzam);
            lblEredmeny.Content = aSzam / bSzam;
        }

        private void btnBtolt_Click(object sender, RoutedEventArgs e)
        {
            if (txtFajlNeve.Text == "")
            {
                MessageBox.Show("Nem adott fájlnevet!");
            }
            lbEredmenyek.Items.Clear();
            try
            {
                StreamReader sr = new StreamReader(txtFajlNeve.Text);
                while (!sr.EndOfStream)
                {
                    lbEredmenyek.Items.Add(sr.ReadLine());
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Nem található a fájl");
                txtFajlNeve.Text = "";
                txtFajlNeve.Focus();
            }
            catch (IOException sas)
            {
                MessageBox.Show("Ismeretlen IO hiba! \n" + sas.Message);
            }
        }
    }
}
